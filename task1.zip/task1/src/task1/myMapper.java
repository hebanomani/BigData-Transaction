package task1;

import java.io.IOException;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class myMapper extends Mapper<LongWritable, Text, Text, NullWritable> {
	public void map(LongWritable myKey, Text myVal, Context cont) throws IOException, InterruptedException{
		String input = myVal.toString();
		String[] eachVal = input.split(",");
		double d = Double.parseDouble(eachVal[3]);
		if(d>160.00){
			Text outputKey = new Text(input);
			cont.write(outputKey,null);
		}
		
		
	}
}
