package task7withCombiner;

import java.io.IOException;

import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class myReducer extends Reducer<Text, Text, DoubleWritable,Text> {
	double max=0.0;
	String id="";
	DoubleWritable rOutKey = new DoubleWritable();
	Text rOutVal = new Text();
	public void reduce(Text rInpKey, Iterable<Text> rInVal,Context c) throws IOException, InterruptedException{
		for(Text eachVal: rInVal){	
		String input=eachVal.toString();
		String[] each = input.split(" ");	
		if(max<Double.parseDouble(each[1].toString())){
			max=Double.parseDouble(each[1].toString());
			id=each[0].toString();
			rOutVal = new Text(id);	
		}
		}
		rOutKey = new DoubleWritable(max);
		c.write(rOutKey, rOutVal);	
	}

}
