package task7withCombiner;

import java.io.IOException;

import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class myCombiner extends Reducer<Text, Text, Text, Text> {
	public void reduce(Text cInpKey, Iterable<Text> cInpVal, Context c) throws IOException, InterruptedException{
		double amt=0.0;
		for(Text eachLine: cInpVal){
			String singleVal =eachLine.toString();
			String[] eachValue = singleVal.split(",");
			amt+=Double.parseDouble(eachValue[3]);
		}
		Text cOutVal= new Text(cInpKey +" " +Double.toString(amt));
		
		c.write(new Text("Max"), cOutVal);
	}

}
