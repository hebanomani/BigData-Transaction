package task7;

import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class myReducer extends Reducer<Text, Text,Text,Text>{
	
	public void reduce(Text inpkey,Iterable<Text> inpVal, Context cont) throws IOException, InterruptedException{
		double max=0.0;
		Text outVal=new Text();
		for(Text singlevalue: inpVal){
			String inpStr =singlevalue.toString();
			String[] eachVal= inpStr.split(",");
			double val=Double.parseDouble(eachVal[3]);
			if(max<val){
				max=val;
				outVal= new Text(inpStr);
				}
		}
		String s=Double.toString(max);
		Text outKey = new Text(s);
	cont.write(outKey,outVal);
}
}

