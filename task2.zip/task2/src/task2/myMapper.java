package task2;

import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class myMapper extends Mapper<LongWritable,Text,Text,IntWritable>{
	public void map(LongWritable key, Text val, Context cont) throws IOException, InterruptedException{
		String input =val.toString();
		String[] inpVal= input.split(",");
		double d =Double.parseDouble(inpVal[3]);
			if(d>160.00){
				Text outputKey = new Text("Total Count");
				IntWritable outputVal = new IntWritable(1);
				cont.write(outputKey, outputVal);
		}
		}
		
	}

