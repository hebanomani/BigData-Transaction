package task6;

import java.io.IOException;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class myMapper extends Mapper<LongWritable,Text,Text,Text>{
	public void map(LongWritable key, Text val, Context cont) throws IOException, InterruptedException{
		String input =val.toString();
		String[] inpVal= input.split(",");
				Text outputKey = new Text(inpVal[3]);
				Text outputVal = new Text(input);
				cont.write(outputKey, outputVal);
		}
		
	}

