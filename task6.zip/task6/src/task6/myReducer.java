package task6;

import java.io.IOException;

import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class myReducer extends Reducer<Text, Text,Text, NullWritable>{
	
	public void reduce(Text inpkey,Text inpVal, Context cont) throws IOException, InterruptedException{
		
	cont.write(inpVal,null);
}
}

