package task5;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Partitioner;

public class myPartitioner extends Partitioner<Text, Text>{

	@Override
	public int getPartition(Text arg0, Text arg1, int arg2) {
		// TODO Auto-generated method stub
		String s1 = arg1.toString();
		if(s1.equalsIgnoreCase("01"))
			return 0;
		else if(s1.equalsIgnoreCase("02"))
			return 1;
		else if(s1.equalsIgnoreCase("03"))
			return 2;
		else if(s1.equalsIgnoreCase("04"))
			return 3;
		else if(s1.equalsIgnoreCase("05"))
			return 4;
		else if(s1.equalsIgnoreCase("06"))
			return 5;
		else if(s1.equalsIgnoreCase("07"))
			return 6;
		else if(s1.equalsIgnoreCase("08"))
			return 7;
		else if(s1.equalsIgnoreCase("09"))
			return 8;
		else if(s1.equalsIgnoreCase("10"))
			return 9;
		else if(s1.equalsIgnoreCase("11"))
			return 10;
		else
			return 11;
	}

}
